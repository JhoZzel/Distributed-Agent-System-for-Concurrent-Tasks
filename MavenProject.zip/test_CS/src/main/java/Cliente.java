

import java.io.*;
import java.net.*;
import java.util.ArrayList;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.ArrayList;

public class Cliente {
    public static void main(String[] args) {
        try (Socket socket = new Socket("localhost", 12345);
             BufferedReader input = new BufferedReader(new InputStreamReader(socket.getInputStream()));
             PrintWriter output = new PrintWriter(socket.getOutputStream(), true);
             BufferedReader consoleInput = new BufferedReader(new InputStreamReader(System.in))) {

            System.out.println("Conectado al servidor. Escribe tus mensajes:");

            String message;
            while (true) {
                // Reading data from the console :0
                String line = consoleInput.readLine();
                int n = Integer.parseInt(line);
                ArrayList<String> A = new ArrayList<String>();
                for (int i = 0; i < n; i++) {
                    String s = consoleInput.readLine();
                    A.add(s);
                }            
                // Testing if the input is correct
                System.out.println("Data: ");
                System.out.println("n : " + n);
                for (int i = 0 ; i < n; i++) {
                    System.out.println("A[i]: " + A.get(i));
                }
                
                // Sending data to the server
                output.println(n);
                for (int i = 0; i < n; i++) {
                    output.println(A.get(i));
                }
                
                // Reading data to the server
                System.out.println("Respuesta del servidor: ");
                line = input.readLine();
                n = Integer.parseInt(line);
                for (int i = 0; i < n; i++) {
                    String s = input.readLine();
                    System.out.println("i = " + i + " => " + s);
                }
                System.out.println("=== FINISH ====");
            }
            
        } catch (IOException e) {
            System.err.println("Error en la comunicación con el servidor: " + e.getMessage());
        }
    }
}

