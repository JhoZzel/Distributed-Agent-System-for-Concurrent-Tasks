package heart_beat;

import java.io.*;
import java.net.*;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Cliente {
    public static void main(String[] args) {    
        try {
            int PUERTO = 8084;
            String ip = "10.10.0.231";
            StreamSocket server = new StreamSocket(new Socket(ip, PUERTO));
            System.out.println("Conectado al servidor, escribe tus mensajes:");
            BufferedReader consoleInput = new BufferedReader(new InputStreamReader(System.in));

            while (true) {
                // Reading data from the console :0
                String line = consoleInput.readLine();
                int n = Integer.parseInt(line);
                StringBuilder mssg = new StringBuilder();
                for (int i = 0; i < n; i++) {
                    line = consoleInput.readLine();
                    mssg.append(line).append('\n');
                }
                
                System.out.println("Sending data to the server");
                server.send(mssg);
                
                // Reading data from the server
                mssg = server.receive();
                System.out.println("Respuesta del servidor: ");
                System.out.println(mssg.toString());
                System.out.println("=== FINISH ====");
            }
                
            
        } catch (IOException ex) {
            Logger.getLogger(Cliente.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
