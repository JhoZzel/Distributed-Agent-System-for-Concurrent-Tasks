/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package heart_beat;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

/**
 *
 * @author jhozzel
 */

class ClientHandle extends Thread {
    private final StreamSocket client;
    private static final int MAX_CONNECTIONS = 2;
    private static ArrayList<StreamSocket> sockets;

    public ClientHandle(StreamSocket client, ArrayList<StreamSocket> sockets) {
        this.client = client;
        this.sockets = sockets;
    }

    @Override
    public void run() {
        try (client) {
            while(true) {
                System.out.println("Reading data from the client...");
                    StringBuilder mssg = client.receive();
                    
                    Scanner sc = new Scanner(mssg.toString());
                    ArrayList<String> lines = new ArrayList<>();
                    while(sc.hasNextLine()) {
                        String line = sc.nextLine();
                        if (line == null || line.equals("") || line.equals("\n")) break;
                        lines.add(line);
                    }
                    
                    int n = lines.size();
                    StringBuilder [] parts = new StringBuilder[MAX_CONNECTIONS];
                    int len = (n + MAX_CONNECTIONS - 1)  / MAX_CONNECTIONS;
                    for (int i = 0; i < MAX_CONNECTIONS; i++) {
                        parts[i] = new StringBuilder();
                        int ini = i * len;
                        int fin = (i + 1) * len;
                        if (i == MAX_CONNECTIONS - 1) fin = n;
                        for (int k = ini; k < fin; k++) {
                            parts[i].append(lines.get(k)).append('\n');
                        }
                    }
                    
                    // test
                    System.out.println("---- Testing");
                    for (int i = 0; i < MAX_CONNECTIONS; i++) {
                        System.out.println("Partition: " + i + ": ");
                        System.out.println(parts[i].toString());
                        System.out.println("");
                    }
                    
                    
                    System.out.println("Assigning taks to every thread....");
                    List<WorkerNodeHandle> handleConnections = new ArrayList<>();
                    for (int i = 0; i < MAX_CONNECTIONS; i++) {
                        WorkerNodeHandle hc = new WorkerNodeHandle(sockets.get(i), parts[i]);
                        hc.start();
                        handleConnections.add(hc);
                    }

                    System.out.println("Waiting for the works of each thread....");
                    for (WorkerNodeHandle hc : handleConnections) {
                        try {
                            hc.join();
                        } catch (InterruptedException e) {
                        }
                    }

                    StringBuilder ans = new StringBuilder();
                    System.out.println("Printing results: ");
                    for (WorkerNodeHandle hc : handleConnections) {
                        StringBuilder res = hc.getResult();
                        System.out.println("=> Results:");
                        System.out.println(res);
                        ans.append(res);
                    }
                    
                    client.send(ans);
                    System.out.println("End....\n");
                
            }
        } catch (IOException e) {
        } finally {
            System.out.println("Client out!....");
        }
    }
}